# Workflow & Contribution Guide — DevOps CI Demo

This repo contains example GitHub Actions workflows and demo code used to learn CI/CD and basic cloud operations.
If you want to contribute or add a workflow, please follow these simple guidelines.

## Quick rules (keeps things clean and professional)
- Place workflows in `.github/workflows/` and name files in **kebab-case**, e.g. `nodejs.yml`.
- Use sentence case for workflow and step names (for example: `Run tests`).
- Add inline comments to any non-obvious steps so reviewers understand why it exists.
- Keep the `GITHUB_TOKEN` permissions minimal — only grant what the workflow needs.
- Use official actions where possible (actions/**) or verified marketplace actions; prefer commit hashes for third-party actions when practical.

## Recommended triggers for demo CI workflows
- CI workflows: run on `push` and `pull_request` to the repository default branch.
- If you want a demo schedule, use a weekly cron job (for learning purposes only).

## Naming & structure
- CI workflows should live under `.github/workflows/ci-*.yml` or `.github/workflows/*-ci.yml`.
- Code scanning / security demos (if any) can live under `.github/workflows/code-scanning-*.yml`.

## Documentation
- Add a short note at the top of any workflow explaining its purpose and the environment it expects.
- Update `README.md` with any new workflow and explain how to trigger it locally or in GitHub.

## Attribution / external templates
- If you base a workflow on a public template, add a one-line note in the README:  
  `Based on: <original repo or template link>` — this is good practice.

## Contact / author
- Repo owner: `2000090079` (Pendurthi Sri Teja)  
- This repo is a learning/demo project — keep changes small and well-documented.

---

Thanks for contributing — small, documented changes make this repo useful for learning and for interviews.
